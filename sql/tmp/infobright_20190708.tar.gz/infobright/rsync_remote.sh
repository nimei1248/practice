#!/bin/bash


RSYNC_IP=xxx.xxx.xxx.xxx
LOCAL_IP=$(/sbin/ip route get 1 | awk '{print $NF;exit}')
TIME=$(date +%Y%m%d)
backup_dir=/ib_backup


## mail
maillist="a1@aa.com a2@aa.com"


## log
last_month=$(date -d '1 month ago' +%Y%m)
the_month=$(date +%Y%m)
log_dir=${backup_dir}/log/${the_month}
last_log_dir=${backup_dir}/log/${last_month}
[ ! -d ${log_dir} ] && mkdir -p $log_dir && chmod 750 $log_dir


#time /usr/bin/rsync -avzcP --port=6666 --bwlimit=30720 --password-file=/home/mysql/.rsync.password ${backup_dir}/*/*.gz MySQL@${RSYNC_IP}::MySQL > ${log_dir}/rsync_remote_${TIME}.log
#rsync_transfer_1=$?

## rsync transfer remote
echo "rsync transfer start $(date +%F_%H:%M:%S)" > ${log_dir}/rsync_remote_${TIME}.log

time /usr/bin/rsync -avzcP --port=6666 --bwlimit=30720 --password-file=/home/mysql/.rsync.password ${backup_dir}/*/*.gz MySQL@${RSYNC_IP}::MySQL >> ${log_dir}/rsync_remote_${TIME}.log
rsync_transfer_1=$?

echo "rsync transfer end $(date +%F_%H:%M:%S)" >> ${log_dir}/rsync_remote_${TIME}.log


cd ${backup_dir}/csv/ && grep '.gz' ${log_dir}/rsync_remote_${TIME}.log && grep '.gz' ${log_dir}/rsync_remote_${TIME}.log | xargs md5sum > ${log_dir}/md5_${LOCAL_IP}_${TIME}.md5
cd ${backup_dir}/sql/ && grep '.gz' ${log_dir}/rsync_remote_${TIME}.log && grep '.gz' ${log_dir}/rsync_remote_${TIME}.log | xargs md5sum >> ${log_dir}/md5_${LOCAL_IP}_${TIME}.md5
time /usr/bin/rsync -avzcP --port=6666 --bwlimit=30720 --password-file=/home/mysql/.rsync.password ${log_dir}/md5_*.md5 MySQL@${RSYNC_IP}::MySQL
rsync_transfer_2=$?


[ $rsync_transfer_1 -eq 0 ] && [ $rsync_transfer_2 -eq 0 ] && {
  (echo "Subject:【db backup remote】from $LOCAL_IP"; cat ${log_dir}/md5_${LOCAL_IP}_${TIME}.md5;) | /usr/sbin/sendmail -f b2@iv66.net $maillist
}

## delete backup log dir
rm -rf $last_log_dir

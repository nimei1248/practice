redis开发了很多数据模型，如果会开发，可以在此基础上进行开发
可以做成redis平台，提供给开发使用，更爽

2.8引入psync -- 2014年
  2.8之前问题：网络闪断，主从会变成全量同步
  2.8引入psync网络闪断1s，可以通过增量传输进行数据
  2.8问题：1主2从场景，主库挂了，从2个从库中选举一个成为master，另一个从库与新master建立主从同步后，需要从新master再拉取一份完整的数据，可怕。
          redis切换，这会导致内网网卡被跑满，复制中断，来回切换。解决方法：1小时内不允许来回切换，只允许单向切换，检查下来回切换原因，再恢复自动来回切换

4.0引入增强psync2.0  -- 2018年
  4.0解决了2.8的问题，支持增量同步(中断、主从切换都支持)

  1.做成一个节点：
    slaveof ip port -- master ip port
    config set masterauth <password> -- 如果有认证，先做认证，主从密码验证

  2.配置文件
    masterauth <password>  密码固定，就写在配置文件中

  3.从库升级为主库
    slaveof no one -- 从slave切换到master slave默认只读
   

redis主从重要参数：
info命令
role:slave
set ab 1 -- slave默认不能修改
slaveof no one -- 将slave改成master，这个新master就与原master没有关系了，除非他们之间执行slaveof ip port变成某一个master的slave
支持域名，需要代码支持

redis主从复制原理：
psync2。0特性：
原group中一个slave提升为master后，其它slave可以从新master做部分同步
原group中slave重启后，slave可以做部分同步

实现原理：
redis在传输rdb文件时，会将自己的id及复制偏移量一起保存在rdb文件中，slave可以从rdb中获取到复制的id及偏移量
slave成为master后，会保存2个复制id，一个自身的复制id，另一个是原master的id信息，其它slave可以通过原master上的信息进行部分复制
info:
master_replid:
master_replid2:
master_repl_offset:
second_repl_offset:

redis复制原理：
第一阶段：与master建立连接
第二阶段：向master发起同步请求(sync)
第三阶段：接受master发来的rdb数据
第四阶段：载入rdb文件

redis：
r1，r2两个redis实例，假设，r1为master，r2为slave，在r2上执行slaveof r1_ip port过程如下：
r2首先会判断角色，是不是cluster状态中，如果是，拒绝执行（cluster不支持slaveof）；如果不是，进行slave角色
向master发起sync命令，master在收到sync命令后会做2件事情：
1。执行bgsave操作，形成rdb文件传给slave（低于4。0版本 master会先将rdb会落盘，现在是内存及传输）
2。master在接收到新的查询时，会保存在缓冲区(方便传增量)
slave接收新的rdb，清空内存，加载rdb，利用接收的rdb文件重新salve的aof文件(避免挂了，又要从主库拉取全量，而优先采用增量)
master后续的变更，通过redis命令协议形式转发给slave，slave执行这些命令，实现和master同步
master/slave不断通过异步方式进行命令同步，达到最终一致性
从redis 2。8 引入psync

关闭区别：
shutdown
kill

验证slave关闭再起来后，是否为增量传输而不是全量
配置文件中指定下
netstat 可以使用端口 sysctl -a | grep port

redis重要参数：
00：37：10
client-output-buffer-limit save 786mb(hard limit) 256mb(soft limit) 60(时间 秒)
config get *buffer-limit*
min-slaves-to-write <number of slaves> 保证至少一个slave被同步到数据
min-slaves-max-lag   slave最大延迟的时间
redis支持读写分离结构，但实际上没有使用从节点做读的：
因为redis本身性能很高的

redis主库挂了，如何切换到slave，通过sentinel：
redis主从高可用：ruser为一组高可用名字 唯一
sentinel monitor ruser 1.1.1.1 6379 1 前面ip：port表示master，投票：后面数字表示有多少sentinel认为挂了，就切换，sentinel的个数要占大多数，超过半数
sentinel down-after milliseconds ruser 60000 60s没有响应，sentinel认为master宕机
sentinel failover-timeout ruser 180000 sentinel切换的超时时间
sentinel parallel-syncs ruser 1
#sentinel notification-script <master name> <shell script-name>
#sentinel client-reconfig-script <master name> <shell script-name>

sentinel 3-5个，最少3个
1主1从 3个sentinel 称为1组
sentinel对java支持比较好，java code直接通过sentinel获取master信息

sentinel 配置文件
启动sentinel redis-sentinel s6379.conf
login sentinel:
redis-cli -h ip -p sentinel_port
sentinel get-master-addr-by-name ruser -- 获取master的ip：port

java代码只需要知道sentinel ip:port, groupname:ruser

前提主从环境+sentinel：
      (m1 + s1)
(r1 + s2)   (r2 + s3)

       m1     r1
(app + s1)  (app + s2) (app + s3)
java app代码服务器上连接本地的sentinel获取redis master的信息，

kill master后观察切换过程，通过sentinel log and server log

redis 分片：
redis cluster：
c，c++貌似用不了cluster
java go python支持cluster
原因：不支持跳转命令


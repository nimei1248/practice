




num = 10
def hi(name='world'):
    print 'hello '+name
print __name__
if __name__ == '__main__':
    print 'xxx'
# coding=utf-8

# num = 1
# name='reboot'


# print 1+2
# print 'a'+'b'
# print [1,2,3]+['b','c']

# html_str = '<table>'
# html_str += '<tr></tr>'
# html_str = html_str+'</table>'
# print html_str

# <table><tr></tr></table>



# python自带模块


# import time
# import os
# import sys
# i = 0
# while True:
#     print i
#     i+=1
#     time.sleep(1)

# 2.第三方 需要pip安装 比如flask requests

# 3.自己的模块


# import hello
# hello.hi()
# hello.hi('xxx')
# print hello.num

# from hello import hi,num
# hi('ooo')
# print num
# as可以起别名
# 1 多个模块名重复
# 2. 模块名实在太难写
#     MySQLdb
# import hello as h
# h.hi()

# import hello
# hello.hi()


# 引入flask
# from flask import Flask
# # 新建app
# app = Flask(__name__)

# # 监听一个路由 /是根目录
# @app.route('/')
# def index():
#         return 'hello world'
# # 监听一个url,路径是/huoying
# @app.route('/huoying')
# # 当这个路由呗访问的时候，出发下面这个函数执行
# def huoying():
#         # 函数的返回值 会显示在浏览器力
#         return 'huoying xxx123'
# # 启动应用
# if __name__=='__main__':
#         host允许所有ip port 监听的端口 debug调试
#         app.run(host='0.0.0.0',port=9092,debug=True)

# 练习：浏览器里显示内存信息



# 协议://域名:端口号/资源地址（/markets/diy/xinnian）?参数(a=1&b=2)
# @app.route监听的 是资源地址
# url里 ？后面是参数，以a=b的形式存在，多个参数用&分割
# 锚点略过
# flask里可以获得的就是资源地址，和参数
# 51reboot.com/a/b/c

# https://www.taobao.com/markets/diy/xinnian
#         ?spm=a21bo.50862.201862-1.d1.KAYJjx&pos=1&acm=20140506001.1003.2.1418808&scm=1003.2.20140506001.OTHER_1481747013048_1418808


# requets获取参数
#     request.args.get(key)
# render_template 渲染模板文件。默认的模板在templates文件夹下面

# redirect 跳转



# http 
#     url
#     method:get 和post
#     据说get由长度限制 其实没有，因为长度限制是浏览器做的，和http协议无关
#     据说get不安全，post安全，其实没有，因为http都是明文传输 get的数据在url力，post的数据在http的body体里
#     get是幂等的 调用多少次 造成的结果都是一样的 post不是幂等



# 表单
# form标签
#     input text:输入框
#     button 按钮
#     submit 提交按钮
# form可以提交数据，action属性是地址，内部的输入框拼接成参数

# https://www.baidu.com/s?wd=python

# https://www.baidu.com/s?wd=javascript



# 练习:浏览器端输入用户名密码，点击提交
# 后端的user.txt里判断是不是有登陆权限





# 作业 用户管理（基于文件存储）

# 1.管理员登陆（写死账号是admin 密码是pwd，不做也可以）
# 2.登陆之后 看到用户和密码列表（存储在文件中）支持添加，删除 的操作
# 3 选做 修改密码

# # jinja2

# render_template（可以传入额外的变量）
# {{变量}} 
# {% python的语法 %}


# {% for xx in  xxx %}


# {% endfor %}



# 前后端分离
# cgi fast-cgi

# return reder_template
# @app.route('xxx')
# def index():
#     for xx 
#         s += '<tr>'

#     return s

# ajax （google的gmail） web2.0

# 前端 前后端分析 ：后端只负责接口，前端负责渲染页面

# 后端只负责数据
# 1.后端语言模板  jinjia2 (python)  smarty(php)  jsp(java)
#     数据+模板渲染成字符串之后  然后给浏览器
#     <p>{{name}}</p>

# 2.前端语言模板吧

#     后端只给数据 前端自己写模板 underscore jade 
#         前端的库自带模板 vue angualr react


# @app.route('/')
# def index():
#     return render_template（’index.html‘）


# @app.route('/userlist')
# def index():

#     return [1,2,3]




# flask django

# django 大而全

# flask 小而美

# bottle web.py tornado


# # web开发

# @app.route()
#     return 返回值渲染浏览器


# request render_template redirdct



# form action
# <form action='xxx'>
#     <input type="text" name="name">
#     <input type="password" name="">
#     <input type="checkbox" name="">
#     <input type="radio" name="">
#     <input type="number" name="">
#     <input type="date" name="">
#     <input type="time" name="">
# </form> -->




# public class bubbleSort {  
#     public bubbleSort(){  
#         int a[]={1,54,6,3,78,34,12,45};  
#         int temp=0;  
#         for(int i=0;i<a.length;i++){  
#            for(int j=i+1;j<a.length;j++){  
#                if(a[i]>a[j]){  
#                    temp=a[i];  
#                    a[i]=a[j];  
#                    a[j]=temp;  
#                }  
#            }  
#         }  
#         for(int i=0;i<a.length;i++) {
#            System.out.println(a[i]);     
#         }
      
#     }  
      
# }  

# def = 1
# 1a = 2
# _a = 1
# aaa= 1

# name = 'world'

# # 下划线
# user_name
# 驼峰
# userName

# _

# 大驼峰 常用来定义类
# UserName



# 常量 
# NUM = 10
# MY_NUM = 10

# 避免的名字
# abcdeff
# a1
# a2
# 临时变量可以用的 
# # for k,v in xx_dict.items()
# # o
# # a = 1

# import hello
# hello.hi()


# from test.hehe import he



# he()

import test
test.xxx()
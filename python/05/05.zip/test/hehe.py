


def he():
    print 'hehehxxx'
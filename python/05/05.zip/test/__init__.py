
def xxx():
    print 'xxx'